import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => MainAppState();
}

class MainAppState extends State<MainApp> {
  int sorteado = Random().nextInt(5) + 1;
  int palpite = 0;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                palpite == 0
                    ? 'Adivinhe o número!'
                    : palpite == sorteado
                        ? 'Acertou!'
                        : 'Errou!',
                style: const TextStyle(fontSize: 24),
              ),
              const SizedBox(height: 30),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (int i = 1; i <= 5; i++)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          foregroundColor: Colors.white,
                          backgroundColor: palpite != 0 && i == sorteado
                              ? Colors.green
                              : palpite == i
                                  ? Colors.red
                                  : Colors.blue,
                        ),
                        onPressed: () {
                          if (palpite == 0) {
                            setState(() => palpite = i);
                          }
                        },
                        child: Text('$i'),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    sorteado = Random().nextInt(5) + 1;
                    palpite = 0;
                  });
                },
                child: const Text('Resetar Jogo'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
