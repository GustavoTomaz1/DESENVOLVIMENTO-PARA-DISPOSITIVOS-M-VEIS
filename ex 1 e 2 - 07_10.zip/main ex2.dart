import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: OrganizaScreen(),
    );
  }
}

class OrganizaScreen extends StatefulWidget {
  const OrganizaScreen({super.key});

  @override
  State<OrganizaScreen> createState() => _OrganizaScreenState();
}

class _OrganizaScreenState extends State<OrganizaScreen> {
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _lerArquivo();
  }

  Future<String> get _caminhoPasta async {
    final diretorio = await getApplicationDocumentsDirectory();
    return diretorio.path;
  }

  Future<File> get _arquivo async {
    final caminho = await _caminhoPasta;
    return File('$caminho/organiza.md');
  }

  Future<void> _lerArquivo() async {
    try {
      final arquivo = await _arquivo;
      final conteudo = await arquivo.readAsString();
      setState(() {
        _controller.text = conteudo;
      });
    } catch (_) {}
  }

  Future<void> _salvarArquivo() async {
    final arquivo = await _arquivo;
    await arquivo.writeAsString(_controller.text);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Salvo com sucesso!')),
    );
  }

  Future<void> _apagarArquivo() async {
    final arquivo = await _arquivo;
    if (await arquivo.exists()) {
      await arquivo.delete();
    }
    setState(() {
      _controller.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Arquivo apagado!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Editor Markdown - organiza.md')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: TextField(
                controller: _controller,
                maxLines: null,
                expands: true,
                decoration: const InputDecoration(
                  hintText: 'escreva aqui',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: _salvarArquivo,
                  child: const Text('Salvar'),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  onPressed: _apagarArquivo,
                  child: const Text('Apagar',
                      style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
