import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const ViaCepApp());

class ViaCepApp extends StatelessWidget {
  const ViaCepApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Consulta CEP',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const BuscaCepScreen(),
    );
  }
}

class BuscaCepScreen extends StatefulWidget {
  const BuscaCepScreen({super.key});

  @override
  State<BuscaCepScreen> createState() => _BuscaCepScreenState();
}

class _BuscaCepScreenState extends State<BuscaCepScreen> {
  final TextEditingController _cepController = TextEditingController();
  final TextEditingController _numeroController = TextEditingController();

  String rua = '';
  String bairro = '';
  String cidade = '';
  String estado = '';
  String numero = '';

  @override
  void initState() {
    super.initState();
    _carregarDadosSalvos();
  }

  Future<void> _carregarDadosSalvos() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _cepController.text = prefs.getString('cep') ?? '';
      _numeroController.text = prefs.getString('numero') ?? '';
      rua = prefs.getString('rua') ?? '';
      bairro = prefs.getString('bairro') ?? '';
      cidade = prefs.getString('cidade') ?? '';
      estado = prefs.getString('estado') ?? '';
    });
  }

  Future<void> _buscarE Salvar() async {
    final cepLimpo = _cepController.text.replaceAll(RegExp(r'[^0-9]'), '');

    if (cepLimpo.length != 8) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('O CEP deve conter 8 dígitos.')),
      );
      return;
    }

    try {
      final url = Uri.parse('https://viacep.com.br/ws/$cepLimpo/json/');
      final resposta = await http.get(url);

      if (resposta.statusCode == 200) {
        final dados = jsonDecode(resposta.body);

        if (dados['erro'] == true || dados['erro'] == 'true') {
          throw Exception('CEP não encontrado.');
        }

        setState(() {
          rua = dados['logradouro'] ?? '';
          bairro = dados['bairro'] ?? '';
          cidade = dados['localidade'] ?? '';
          estado = dados['uf'] ?? '';
          numero = _numeroController.text;
        });

        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('cep', _cepController.text);
        await prefs.setString('numero', _numeroController.text);
        await prefs.setString('rua', rua);
        await prefs.setString('bairro', bairro);
        await prefs.setString('cidade', cidade);
        await prefs.setString('estado', estado);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Endereço guardado com sucesso!')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro: $e')),
      );
    }
  }

  Future<void> _apagarDados() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    setState(() {
      _cepController.clear();
      _numeroController.clear();
      rua = '';
      bairro = '';
      cidade = '';
      estado = '';
      numero = '';
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Dados apagados!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Buscador de CEP')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: _cepController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Digite o CEP',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _numeroController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Número da casa',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _buscarE Salvar,
              child: const Text('Buscar e Salvar'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: _apagarDados,
              child: const Text('Apagar Dados', style: TextStyle(color: Colors.white)),
            ),
            const SizedBox(height: 24),
            const Text(
              'Endereço Carregado:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('Rua: $rua'),
            Text('Número: $numero'),
            Text('Bairro: $bairro'),
            Text('Cidade: $cidade'),
            Text('Estado: $estado'),
          ],
        ),
      ),
    );
  }
}