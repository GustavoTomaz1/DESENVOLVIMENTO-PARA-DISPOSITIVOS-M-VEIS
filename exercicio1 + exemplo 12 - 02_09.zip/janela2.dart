import 'package:flutter/material.dart';
import 'package:flutter_application_2/pergunta.dart';
import 'package:flutter_application_2/questoes.dart';

class Janela2 extends StatelessWidget {
  const Janela2({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    Pergunta teste1 = questoes[0];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Quiz de Física'),
      ),
      body: SizedBox(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Text(
                teste1.texto,
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Column(
              children: [
                ElevatedButton(
                  onPressed: () {
                    print('Resposta 1 selecionada');
                  },
                  child: Text(teste1.respostas[0]),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () {
                    print('Resposta 2 selecionada');
                  },
                  child: Text(teste1.respostas[1]),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () {
                    print('Resposta 3 selecionada');
                  },
                  child: Text(teste1.respostas[2]),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () {
                    print('Resposta 4 selecionada');
                  },
                  child: Text(teste1.respostas[3]),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
