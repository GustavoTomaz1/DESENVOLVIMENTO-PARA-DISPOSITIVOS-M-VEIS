import 'package:flutter/material.dart';

class Janela1 extends StatelessWidget {
  const Janela1(
    this.muda, {
    super.key,
  });

  final Function() muda;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Opacity(
              opacity: 0.8,
              child: Image.asset(
                'assets/imagens/fisica.png', // Lembre-se de adicionar esta imagem ou alterar o nome
              ),
            ),
          ),
          const Text(
            'Aperte o botão para iniciar o Quiz de Física:',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.center,
          ),
          const SizedBox(
            height: 20,
          ),
          ElevatedButton.icon(
            icon: const Icon(
              Icons.arrow_right_alt,
            ),
            onPressed: () {
              print('Iniciando o Quiz...');
              muda();
            },
            label: const Text('Iniciar Quiz'),
          ),
        ],
      ),
    );
  }
}
