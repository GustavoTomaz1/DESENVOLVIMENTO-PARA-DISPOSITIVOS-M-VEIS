import 'package:flutter_application_2/pergunta.dart';

const questoes = [
  Pergunta(
      '1. Qual é a unidade de medida da corrente elétrica no Sistema Internacional?',
      ['Ampere', 'Volts', 'Ohm', 'Watt']),
  Pergunta(
      '2. Qual lei da física afirma que para toda ação existe uma reação de igual intensidade?',
      ['3ª Lei de Newton', '1ª Lei de Newton', 'Lei da Inércia', 'Lei de Ohm']),
  Pergunta('3. A velocidade da luz no vácuo é de aproximadamente:',
      ['300.000 km/s', '150.000 km/s', '340 m/s', '1.000 km/h']),
];
