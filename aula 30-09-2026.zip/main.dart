import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const ViaCepApp());

class Endereco {
  final String rua;
  final String bairro;
  final String cidade;
  final String estado;

  Endereco({
    required this.rua,
    required this.bairro,
    required this.cidade,
    required this.estado,
  });

  factory Endereco.fromJson(Map<String, dynamic> json) {
    if (json['erro'] == true || json['erro'] == "true") {
      throw Exception('CEP não encontrado na base de dados.');
    }

    return Endereco(
      rua: json['logradouro'] ?? '',
      bairro: json['bairro'] ?? '',
      cidade: json['localidade'] ?? '',
      estado: json['estado'] ?? json['uf'] ?? '',
    );
  }
}

class ViaCepApp extends StatelessWidget {
  const ViaCepApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Consulta CEP',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const BuscaCepScreen(),
    );
  }
}

class BuscaCepScreen extends StatefulWidget {
  const BuscaCepScreen({super.key});

  @override
  State<BuscaCepScreen> createState() => _BuscaCepScreenState();
}

class _BuscaCepScreenState extends State<BuscaCepScreen> {
  final TextEditingController _cepController = TextEditingController();
  Future<Endereco>? _enderecoFuturo;

  Future<Endereco> buscarCep(String cep) async {
    final cepLimpo = cep.replaceAll(RegExp(r'[^0-9]'), '');

    if (cepLimpo.length != 8) {
      throw Exception('O CEP deve conter 8 dígitos.');
    }

    final url = Uri.parse('https://viacep.com.br/ws/$cepLimpo/json/');
    final resposta = await http.get(url);

    if (resposta.statusCode == 200) {
      return Endereco.fromJson(jsonDecode(resposta.body));
    } else {
      throw Exception('Erro ao consultar o CEP.');
    }
  }

  void _pesquisar() {
    setState(() {
      _enderecoFuturo = buscarCep(_cepController.text);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('buscador de CEP')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _cepController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'digite o cep',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _pesquisar,
              child: const Text('buscar Endereço'),
            ),
            const SizedBox(height: 32),
            Expanded(
              child: _enderecoFuturo == null
                  ? const Center(child: Text('digite um cep para buscar.'))
                  : FutureBuilder<Endereco>(
                      future: _enderecoFuturo,
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(
                              child: CircularProgressIndicator());
                        } else if (snapshot.hasError) {
                          return Center(
                            child: Text(
                              '${snapshot.error}',
                              style: const TextStyle(color: Colors.red),
                              textAlign: TextAlign.center,
                            ),
                          );
                        } else if (snapshot.hasData) {
                          final endereco = snapshot.data!;
                          return ListView(
                            children: [
                              ListTile(
                                title: const Text('Rua',
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold)),
                                subtitle: Text(endereco.rua.isEmpty
                                    ? 'Não informada'
                                    : endereco.rua),
                              ),
                              ListTile(
                                title: const Text('Bairro',
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold)),
                                subtitle: Text(endereco.bairro.isEmpty
                                    ? 'Não informado'
                                    : endereco.bairro),
                              ),
                              ListTile(
                                title: const Text('Cidade',
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold)),
                                subtitle: Text(endereco.cidade),
                              ),
                              ListTile(
                                title: const Text('Estado',
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold)),
                                subtitle: Text(endereco.estado),
                              ),
                            ],
                          );
                        }
                        return const SizedBox.shrink();
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
